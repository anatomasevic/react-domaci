
import './App.css';
import Top from './components/Top';
import Form from './components/Form';
import Navbar from './components/Navbar';


import TodoList from './components/TodoList';

function App() {
  return (
    <div className="App">
    <Top></Top>
    </div>
  );
}

export default App;
